public class practicalEightA {
    private static int max = 10;
    private static int number = 1;

    public static void main(String[] args) {
        Object lock = new Object();

        Thread evenThread = new Thread(new EvenPrinter(lock));
        Thread oddThread = new Thread(new OddPrinter(lock));

        evenThread.start();
        oddThread.start();
    }

    static class EvenPrinter implements Runnable {
        private final Object lock;

        public EvenPrinter(Object lock) {
            this.lock = lock;
        }

        @Override
        public void run() {
            while (number <= max) {
                synchronized (lock) {
                    if (number % 2 == 0) {
                        System.out.println("Even: " + number);
                        number++;
                        lock.notify();
                    } else {
                        try {
                            lock.wait();
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                        }
                    }
                }
            }
        }
    }

    static class OddPrinter implements Runnable {
        private final Object lock;

        public OddPrinter(Object lock) {
            this.lock = lock;
        }

        @Override
        public void run() {
            while (number <= max) {
                synchronized (lock) {
                    if (number % 2 != 0) {
                        System.out.println("Odd: " + number);
                        number++;
                        lock.notify();
                    } else {
                        try {
                            lock.wait();
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                        }
                    }
                }
            }
        }
    }
}
