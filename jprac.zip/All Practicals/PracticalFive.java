// Define the Vehicle interface
interface Vehicle {
    void changeGear(int gear);

    void speedUp(int increment);

    void applyBrakes(int decrement);
}

// Implement the Bicycle class
class Bicycle implements Vehicle {
    private int speed;
    private int gear;

    public void changeGear(int newGear) {
        gear = newGear;
    }

    public void speedUp(int increment) {
        speed += increment;
    }

    public void applyBrakes(int decrement) {
        speed -= decrement;
    }

    public void printStatus() {
        System.out.println("Bicycle: Gear = " + gear + ", Speed = " + speed);
    }
}

// Implement the Car class
class Car implements Vehicle {
    private int speed;
    private int gear;

    public void changeGear(int newGear) {
        gear = newGear;
    }

    public void speedUp(int increment) {
        speed += increment;
    }

    public void applyBrakes(int decrement) {
        speed -= decrement;
    }

    public void printStatus() {
        System.out.println("Car: Gear = " + gear + ", Speed = " + speed);
    }
}

// Implement the Bike class
class Bike implements Vehicle {
    private int speed;
    private int gear;

    public void changeGear(int newGear) {
        gear = newGear;
    }

    public void speedUp(int increment) {
        speed += increment;
    }

    public void applyBrakes(int decrement) {
        speed -= decrement;
    }

    public void printStatus() {
        System.out.println("Bike: Gear = " + gear + ", Speed = " + speed);
    }
}

public class PracticalFive {
    public static void main(String[] args) {
        Bicycle bicycle = new Bicycle();
        bicycle.changeGear(2);
        bicycle.speedUp(20);
        bicycle.applyBrakes(5);
        bicycle.printStatus();

        Car car = new Car();
        car.changeGear(3);
        car.speedUp(60);
        car.applyBrakes(10);
        car.printStatus();

        Bike bike = new Bike();
        bike.changeGear(1);
        bike.speedUp(15);
        bike.applyBrakes(3);
        bike.printStatus();
    }
}
