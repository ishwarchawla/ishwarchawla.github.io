import java.awt.*;
import java.awt.event.*;

public class practicalEleven extends Frame {
    private Button[] colorButtons = new Button[6];
    private String[] colorNames = { "Red", "Green", "Blue", "Yellow", "Purple", "Orange" };

    public practicalEleven() {
        setTitle("Color Palette");
        setSize(300, 200);
        setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10)); // Adding margin
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent) {
                System.exit(0);
            }
        });

        Panel buttonPanel = new Panel();
        buttonPanel.setLayout(new GridLayout(2, 3));

        for (int i = 0; i < colorButtons.length; i++) {
            colorButtons[i] = new Button(colorNames[i]);
            colorButtons[i].addActionListener(new ColorButtonListener());
            buttonPanel.add(colorButtons[i]);
        }

        add(buttonPanel);
        setVisible(true);
    }

    class ColorButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String buttonLabel = ((Button) e.getSource()).getLabel();
            changeBackgroundColor(buttonLabel);
        }

        private void changeBackgroundColor(String colorName) {
            Color newColor = Color.WHITE; // Default color

            switch (colorName) {
                case "Red":
                    newColor = Color.RED;
                    break;
                case "Green":
                    newColor = Color.GREEN;
                    break;
                case "Blue":
                    newColor = Color.BLUE;
                    break;
                case "Yellow":
                    newColor = Color.YELLOW;
                    break;
                case "Purple":
                    newColor = new Color(128, 0, 128); // Purple
                    break;
                case "Orange":
                    newColor = new Color(255, 140, 0); // Orange
                    break;
            }

            setBackground(newColor);
        }
    }

    public static void main(String[] args) {
        new practicalEleven();
    }
}
