class Employee {
    private String name;
    private int yearOfJoining;
    private double salary;
    private String address;

    // Constructor to initialize employee information
    public Employee(String name, int yearOfJoining, double salary, String address) {
        this.name = name;
        this.yearOfJoining = yearOfJoining;
        this.salary = salary;
        this.address = address;
    }

    // Method to display employee information
    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Year of Joining: " + yearOfJoining);
        System.out.println("Salary: " + salary);
        System.out.println("Address: " + address);
        System.out.println();
    }
}

public class PracticalThree_a {
    public static void main(String[] args) {
        // Create three Employee objects
        Employee employee1 = new Employee("Robert", 1994, 60000.0, "64C - WallStreat");
        Employee employee2 = new Employee("Alice Johnson", 2000, 55000.0, "68D - WallStreat");
        Employee employee3 = new Employee("Bob Brown", 1999, 70000.0, "26B - WallStreat");

        // Display information for each employee
        System.out.println("Employee Information:");
        employee1.displayInfo();
        employee2.displayInfo();
        employee3.displayInfo();
    }
}
