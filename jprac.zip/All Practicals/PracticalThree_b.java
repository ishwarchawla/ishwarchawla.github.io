class MyClass {
    private int value;

    // Default constructor
    public MyClass() {
        this(0); // Calls parameterized constructor with value 0
    }

    // Parameterized constructor with an integer parameter
    public MyClass(int value) {
        this.value = value;
    }

    // Getter method to retrieve the value
    public int getValue() {
        return value;
    }
}

public class PracticalThree_b {
    public static void main(String[] args) {
        // Create objects using different constructors
        MyClass obj1 = new MyClass(); // Calls the default constructor
        MyClass obj2 = new MyClass(42); // Calls the parameterized constructor

        // Display values
        System.out.println("Value of obj1: " + obj1.getValue()); // Should print 0
        System.out.println("Value of obj2: " + obj2.getValue()); // Should print 42
    }
}
