import java.awt.*;
import java.awt.event.*;

public class practicalTen extends Frame {
    private Label nameLabel, ageLabel, genderLabel, courseLabel;
    private TextField nameField, ageField;
    private Choice genderChoice;
    private CheckboxGroup courseGroup;
    private Checkbox javaCheckbox, pythonCheckbox, csharpCheckbox;
    private Button submitButton;

    public practicalTen() {
        setTitle("Student Profile Form");
        setSize(300, 200);
        setLayout(new GridLayout(6, 2));
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent) {
                System.exit(0);
            }
        });

        nameLabel = new Label("Name: ");
        ageLabel = new Label("Age: ");
        genderLabel = new Label("Gender: ");
        courseLabel = new Label("Courses: ");

        nameField = new TextField(20);
        ageField = new TextField(20);

        genderChoice = new Choice();
        genderChoice.add("Male");
        genderChoice.add("Female");
        genderChoice.add("Other");

        courseGroup = new CheckboxGroup();
        javaCheckbox = new Checkbox("Java", courseGroup, false);
        pythonCheckbox = new Checkbox("Python", courseGroup, false);
        csharpCheckbox = new Checkbox("C#", courseGroup, false);

        submitButton = new Button("Submit");
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayProfile();
            }
        });

        add(nameLabel);
        add(nameField);
        add(ageLabel);
        add(ageField);
        add(genderLabel);
        add(genderChoice);
        add(courseLabel);
        add(javaCheckbox);
        add(pythonCheckbox);
        add(csharpCheckbox);
        add(new Label("")); // Empty label for spacing
        add(submitButton);

        setVisible(true);
    }

    private void displayProfile() {
        String name = nameField.getText();
        String age = ageField.getText();
        String gender = genderChoice.getSelectedItem();
        String courses = "";

        if (javaCheckbox.getState()) {
            courses += "Java, ";
        }
        if (pythonCheckbox.getState()) {
            courses += "Python, ";
        }
        if (csharpCheckbox.getState()) {
            courses += "C#, ";
        }

        courses = courses.substring(0, courses.length() - 2); // Remove the trailing comma and space

        String profile = "Name: " + name + "\nAge: " + age + "\nGender: " + gender + "\nCourses: " + courses;

        TextArea resultArea = new TextArea(profile);
        resultArea.setEditable(false);
        new Frame("Student Profile").add(resultArea);
        resultArea.setSize(300, 150);
        resultArea.setVisible(true);
    }

    public static void main(String[] args) {
        new practicalTen();
    }
}
