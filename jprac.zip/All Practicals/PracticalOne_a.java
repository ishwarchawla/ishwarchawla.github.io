import java.util.Scanner;

public class PracticalOne_a {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter employee number: ");
        int empNo = scanner.nextInt();

        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter employee name: ");
        String empName = scanner.nextLine();

        System.out.print("Enter basic salary: ");
        double basicSalary = scanner.nextDouble();

        // Calculate DA, HRA, CCA, PF, and PT
        double da = 0.70 * basicSalary;
        double hra = 0.30 * basicSalary;
        double cca = 240;
        double pf = 0.10 * basicSalary;
        double pt = 100;

        // Calculate gross salary
        double grossSalary = basicSalary + da + hra + cca;

        // Calculate net salary
        double netSalary = grossSalary - pf - pt;

        // Display the results
        System.out.println("\nSalary Details for Employee: " + empName);
        System.out.println("Employee Number: " + empNo);
        System.out.println("Basic Salary: Rs. " + basicSalary);
        System.out.println("DA: Rs. " + da);
        System.out.println("HRA: Rs. " + hra);
        System.out.println("CCA: Rs. " + cca);
        System.out.println("PF: Rs. " + pf);
        System.out.println("PT: Rs. " + pt);
        System.out.println("Gross Salary: Rs. " + grossSalary);
        System.out.println("Net Salary: Rs. " + netSalary);

        scanner.close();
    }
}
