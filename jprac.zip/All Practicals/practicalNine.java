import java.awt.*;
import java.awt.event.*;

public class practicalNine {
    private Frame frame;
    private TextField textField;
    private String currentInput = "";
    private double result = 0;
    private char operator = ' ';

    public practicalNine() {
        frame = new Frame("Simple Calculator");
        textField = new TextField(20);
    }

    public void createUI() {
        frame.setLayout(new BorderLayout());
        frame.add(textField, BorderLayout.NORTH);

        Panel buttonPanel = new Panel();
        buttonPanel.setLayout(new GridLayout(4, 4));

        String[] buttonLabels = {
                "7", "8", "9", "/",
                "4", "5", "6", "*",
                "1", "2", "3", "-",
                "C", "0", "=", "+"
        };

        for (String label : buttonLabels) {
            Button button = new Button(label);
            button.addActionListener(new ButtonClickListener());
            buttonPanel.add(button);
        }

        frame.add(buttonPanel, BorderLayout.CENTER);

        frame.setSize(300, 300);
        frame.setVisible(true);
    }

    class ButtonClickListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String buttonLabel = e.getActionCommand();

            if (Character.isDigit(buttonLabel.charAt(0))) {
                currentInput += buttonLabel;
                textField.setText(currentInput);
            } else if (buttonLabel.equals("C")) {
                clearInput();
            } else if (buttonLabel.equals("=")) {
                calculateResult();
            } else {
                if (!currentInput.isEmpty()) {
                    if (operator != ' ') {
                        calculateResult();
                    }
                    operator = buttonLabel.charAt(0);
                    result = Double.parseDouble(currentInput);
                    currentInput = "";
                    textField.setText(currentInput);
                }
            }
        }

        private void clearInput() {
            currentInput = "";
            operator = ' ';
            result = 0;
            textField.setText(currentInput);
        }

        private void calculateResult() {
            if (!currentInput.isEmpty()) {
                double inputNumber = Double.parseDouble(currentInput);
                switch (operator) {
                    case '+':
                        result += inputNumber;
                        break;
                    case '-':
                        result -= inputNumber;
                        break;
                    case '*':
                        result *= inputNumber;
                        break;
                    case '/':
                        if (inputNumber != 0) {
                            result /= inputNumber;
                        } else {
                            textField.setText("Error");
                            return;
                        }
                        break;
                }
                currentInput = "";
                operator = ' ';
                textField.setText(Double.toString(result));
            }
        }
    }

    public static void main(String[] args) {
        practicalNine calculator = new practicalNine();
        calculator.createUI();
    }
}
