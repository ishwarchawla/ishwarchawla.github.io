public class PracticalSix {
    public static void main(String[] args) {
        int amount = 13456;
        String words = AmountInWords.convertToWords(amount);
        System.out.println("Amount in words: " + words);
    }
}
