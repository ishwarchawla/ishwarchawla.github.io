class Student {
    private String name;
    private int age;
    private String address;

    // Default constructor
    public Student() {
        name = "unknown";
        age = 0;
        address = "not available";
    }

    // Setter method with two parameters
    public void setInfo(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Setter method with three parameters
    public void setInfo(String name, int age, String address) {
        this.name = name;
        this.age = age;
        this.address = address;
    }

    // Getter method for name
    public String getName() {
        return name;
    }

    // Getter method for age
    public int getAge() {
        return age;
    }

    // Getter method for address
    public String getAddress() {
        return address;
    }
}

public class PracticalTwo_b {
    public static void main(String[] args) {
        Student[] students = new Student[10];

        // Initialize and set information for 10 students
        for (int i = 0; i < 10; i++) {
            students[i] = new Student();

            // Set information for each student using the appropriate method
            if (i % 2 == 0) {
                students[i].setInfo("Student" + (i + 1), 20 + i, "Address" + (i + 1));
            } else {
                students[i].setInfo("Student" + (i + 1), 20 + i);
            }
        }

        // Print the information for all students
        System.out.println("Student Information:");
        for (int i = 0; i < 10; i++) {
            System.out.println("Student " + (i + 1));
            System.out.println("Name: " + students[i].getName());
            System.out.println("Age: " + students[i].getAge());
            System.out.println("Address: " + students[i].getAddress());
            System.out.println();
        }
    }
}
