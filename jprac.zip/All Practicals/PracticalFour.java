class Student {
    private String name;
    private int age;
    private String address;

    public Student(String name, int age, String address) {
        this.name = name;
        this.age = age;
        this.address = address;
        System.out.println("-----Student Information-----");
        System.out.println("Student Name: " + this.name);
        System.out.println("Student Age: " + this.age);
        System.out.println("Student Address: " + this.address);
    }
}

class Graduate extends Student {
    private String stream;
    private float percentage;

    public Graduate(String name, int age, String address, String stream, double d) {
        super(name, age, address);
        this.stream = stream;
        this.percentage = (float) d;
    }

    public void display_student_info() {
        System.out.println("Student Stream: " + this.stream);
        System.out.println("Student Percentage: " + this.percentage);
    }
}

class Research extends Student {
    private String specialization;
    private int experience;

    public Research(String name, int age, String address, String specialization, int experience) {
        super(name, age, address);
        this.specialization = specialization;
        this.experience = experience;
    }

    public void display_student_info() {
        System.out.println("Student Specialization: " + this.specialization);
        System.out.println("Student Experience: " + this.experience);
    }
}

class PracticalFour {
    public static void main(String[] args) {
        Graduate gungun = new Graduate("Gungun", 19, "Chembur", "Science", 75.00);
        gungun.display_student_info();
        // Researcher
        Research harshit = new Research("Harshit", 19, "Ulhasnagar", "Data Science", 3);
        harshit.display_student_info();
    }
}