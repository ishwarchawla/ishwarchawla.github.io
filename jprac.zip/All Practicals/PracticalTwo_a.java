import java.util.Scanner;

public class PracticalTwo_a {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double[] speeds = new double[5];
        double totalSpeed = 0;

        // Input speeds of racers
        for (int i = 0; i < 5; i++) {
            System.out.print("Enter speed of racer " + (i + 1) + " (in km/h): ");
            speeds[i] = scanner.nextDouble();
            totalSpeed += speeds[i];
        }

        // Calculate average speed
        double averageSpeed = totalSpeed / 5;

        System.out.println("\nAverage speed of all racers: " + averageSpeed + " km/h");
        System.out.println("Qualifying racers (speed > average speed):");

        // Print speeds of qualifying racers
        for (int i = 0; i < 5; i++) {
            if (speeds[i] > averageSpeed) {
                System.out.println("Racer " + (i + 1) + ": " + speeds[i] + " km/h");
            }
        }

        scanner.close();
    }
}
