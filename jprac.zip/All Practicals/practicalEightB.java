class BankAccount {
    private double balance;

    public BankAccount(double initialBalance) {
        this.balance = initialBalance;
    }

    public synchronized double getBalance() {
        return balance;
    }

    public synchronized void deposit(double amount) {
        balance += amount;
    }

    public synchronized void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
        } else {
            System.out.println("Insufficient balance to withdraw " + amount);
        }
    }
}

class TransactionThread extends Thread {
    private BankAccount account;
    private String action;
    private double amount;

    public TransactionThread(BankAccount account, String action, double amount) {
        this.account = account;
        this.action = action;
        this.amount = amount;
    }

    @Override
    public void run() {
        if (action.equals("deposit")) {
            account.deposit(amount);
            System.out.println(Thread.currentThread().getName() + " deposited " + amount);
        } else if (action.equals("withdraw")) {
            account.withdraw(amount);
            System.out.println(Thread.currentThread().getName() + " withdrew " + amount);
        } else if (action.equals("balance")) {
            double balance = account.getBalance();
            System.out.println(Thread.currentThread().getName() + " checked balance: " + balance);
        }
    }
}

public class practicalEightB {
    public static void main(String[] args) {
        BankAccount sharedAccount = new BankAccount(1000.0);

        Thread joe = new TransactionThread(sharedAccount, "deposit", 200.0);
        Thread john = new TransactionThread(sharedAccount, "withdraw", 300.0);
        Thread mom = new TransactionThread(sharedAccount, "balance", 0.0);

        joe.start();
        john.start();
        mom.start();
    }
}
