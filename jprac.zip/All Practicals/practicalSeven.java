import java.util.Scanner;

class InvalidPasswordException extends Exception {
    public InvalidPasswordException(String message) {
        super(message);
    }
}

public class practicalSeven {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter your login ID: ");
            scanner.nextLine();

            System.out.print("Enter your password: ");
            String password = scanner.nextLine();

            try {
                if (isValidPassword(password)) {
                    System.out.println("Login Successful");
                } else {
                    throw new InvalidPasswordException(
                            "Please enter a valid password of length 8 containing one digit and one special symbol.");
                }
            } catch (InvalidPasswordException e) {
                System.out.println("Login Failed: " + e.getMessage());
            }
        }
    }

    private static boolean isValidPassword(String password) {
        if (password.length() == 8) {
            boolean containsDigit = false;
            boolean containsSpecialSymbol = false;

            for (char c : password.toCharArray()) {
                if (Character.isDigit(c)) {
                    containsDigit = true;
                } else if (!Character.isLetterOrDigit(c)) {
                    containsSpecialSymbol = true;
                }
            }

            return containsDigit && containsSpecialSymbol;
        }
        return false;
    }
}
