
public class AmountInWords {
    private static final String[] units = {
            "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
            "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"
    };

    private static final String[] tens = {
            "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
    };

    public static String convertToWords(int amount) {
        if (amount == 0) {
            return "Zero";
        }

        if (amount < 0 || amount > 100000) {
            return "Invalid amount";
        }

        if (amount < 20) {
            return units[amount];
        }

        if (amount < 100) {
            return tens[amount / 10] + " " + units[amount % 10];
        }

        if (amount < 1000) {
            return units[amount / 100] + " Hundred " + convertToWords(amount % 100);
        }

        if (amount < 100000) {
            return convertToWords(amount / 1000) + " Thousand " + convertToWords(amount % 1000);
        }

        return "Invalid amount";
    }
}
