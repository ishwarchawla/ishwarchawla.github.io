import java.util.Scanner;

class BankAccount {
    private String customerName;
    private long accountNumber;
    private double balance;
    private double interestRate;
    private String contactNumber;
    private String address;

    public BankAccount() {
        customerName = "";
        accountNumber = 0;
        balance = 0.0;
        interestRate = 0.0;
        contactNumber = "";
        address = "";
    }

    public void createAccount() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter customer name: ");
            customerName = scanner.nextLine();

            System.out.print("Enter account number: ");
            accountNumber = scanner.nextLong();

            System.out.print("Enter initial balance: ");
            balance = scanner.nextDouble();

            System.out.print("Enter interest rate: ");
            interestRate = scanner.nextDouble();

            scanner.nextLine(); // Consume the newline character

            System.out.print("Enter contact number: ");
            contactNumber = scanner.nextLine();

            System.out.print("Enter address: ");
            address = scanner.nextLine();
        }

        System.out.println("Account created successfully!");
    }

    public void deposit() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter the amount to deposit: ");
            double amount = scanner.nextDouble();

            if (amount > 0) {
                balance += amount;
                System.out.println("Deposit successful!");
            } else {
                System.out.println("Invalid amount. Deposit failed.");
            }
        }
    }

    public void withdraw() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter the amount to withdraw: ");
            double amount = scanner.nextDouble();

            if (amount > 0 && amount <= balance) {
                balance -= amount;
                System.out.println("Withdrawal successful!");
            } else {
                System.out.println("Invalid amount or insufficient balance. Withdrawal failed.");
            }
        }
    }

    public void computeInterest() {
        double interest = (balance * interestRate) / 100;
        balance += interest;
        System.out.println("Interest calculated and added to the account!");
    }

    public void displayBalance() {
        System.out.println("Account Information:");
        System.out.println("Customer Name: " + customerName);
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: Rs. " + balance);
        System.out.println("Interest Rate: " + interestRate + "%");
        System.out.println("Contact Number: " + contactNumber);
        System.out.println("Address: " + address);
    }
}

public class PracticalOne_b {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BankAccount account = new BankAccount();

        while (true) {
            System.out.println("\nBanking Application Menu:");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Compute Interest");
            System.out.println("5. Display Balance");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    account.createAccount();
                    break;
                case 2:
                    account.deposit();
                    break;
                case 3:
                    account.withdraw();
                    break;
                case 4:
                    account.computeInterest();
                    break;
                case 5:
                    account.displayBalance();
                    break;
                case 6:
                    System.out.println("Exiting the application. Goodbye!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
